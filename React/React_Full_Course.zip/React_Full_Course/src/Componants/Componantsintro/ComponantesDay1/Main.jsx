import webpackImg from './Webpack-for-React.jpg';

function Main() {
    return (
        <div className="main">
            <section id="hero">
                <img src={webpackImg} alt="Webpack for React" />
                <h1>hello</h1>
            </section>
             <section id="hero">
                <img src={webpackImg} alt="Webpack for React" />
                <h1>hello</h1>
            </section>
        </div>
    )
}
export default Main;