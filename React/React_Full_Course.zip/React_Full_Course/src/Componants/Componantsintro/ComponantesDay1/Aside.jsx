
let Aside=()=>{
    return(
        <div> 
            {/* <h1>from aside</h1> */}

            <div className="aside">
                 <a href="#home">Home</a>
                <a href="#products">Product</a>
                <a href="#contact">Contact</a>
                <a href="#about">About</a>
                <a href="#cart">Cart</a>
            </div>
        </div>
    )
}

export  default Aside;