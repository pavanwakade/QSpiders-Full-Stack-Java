import Aside from "./Aside.jsx";
import Main from "./Main.jsx";
import NavBar from "./NavBar.jsx";

let ComponantsDay1 = () => {
    return (
        <div>
            {/* <h1>hello  from Day1</h1> */}


            <NavBar />

            <Main />
            <Aside />

        </div>
    )
}

export default ComponantsDay1;