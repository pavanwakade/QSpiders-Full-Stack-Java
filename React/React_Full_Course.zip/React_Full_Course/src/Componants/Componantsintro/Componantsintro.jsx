import ComponantsDay1 from "./ComponantesDay1/ComponantsDay1.jsx";

let Componantsintro=()=>{
    return(
        <div>
            {/* <h1>hello from intro</h1> */}
            <ComponantsDay1 />
        </div>
    )
}

export default Componantsintro;