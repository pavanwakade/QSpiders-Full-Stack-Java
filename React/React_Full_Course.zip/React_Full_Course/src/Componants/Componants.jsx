// import Componantsintro from "./Componantsintro/Componantsintro.jsx";

import Hooksintro from "./hooks/Hooksintro";

let Components=()=>{
    return(
        <div>
            {/* <h1>hello from Componants</h1> */}

            {/* <Componantsintro /> */}
            <Hooksintro />
        </div>
    )
}

export default Components;