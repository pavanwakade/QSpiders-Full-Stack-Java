import UseStateIntro from "./useStateHooks/UseStateIntro";

let Hooksintro = () => {
    return (
        <div>
            {/* <h1>hooksintro</h1> */}

            <UseStateIntro />
        </div>
    )
}

export default Hooksintro;