let UseStateTask6=()=>{
    return(
        <div style={{display:"flex",justifyContent:"center",alignContent:"center", height:"100vh",width:"100"}}>
            {/* <h1>hello</h1> */}
            <div style={{
                width:"50px",
                height:"50px",
                borderRadius:"50%",
                border:"1px solid black"
            }}></div>
        </div>
    )
}

export default UseStateTask6;