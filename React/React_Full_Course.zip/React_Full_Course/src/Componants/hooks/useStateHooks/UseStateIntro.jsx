import UseStateTask6 from "./tasks/UseStateTask6";

let UseStateIntro = () => {
    return (
        <div>
            {/* <h1>usestate</h1> */}
            {/* <UseStateTask1 />
            <UseStateTask2 /> */}
            {/* < UseStateTask3 /> */}
            {/* <Card /> */}
            {/* <UseStateTask4 /> */}
            <UseStateTask6 />

        </div>

    )
}
export default UseStateIntro;