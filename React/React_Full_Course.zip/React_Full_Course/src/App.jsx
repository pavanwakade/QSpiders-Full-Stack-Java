import './App.css';
import Components from "./Componants/Componants";
let App=()=>{

  return(
    <div>
      {/* <h1>hello from App.jsx</h1> */}
      <Components />
    </div>
  )
}

export default App;